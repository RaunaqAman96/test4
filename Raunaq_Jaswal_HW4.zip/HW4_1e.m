clearvars -except W_speech;
clc;

[x,fs]=audioread("noise_train.wav");

win=hamming(1024);
hop=512;
%%Calculating spectrogram
[v,f,t]=stft(x,'FFTLength',2048,'Window',win,'OverlapLength',length(win)-hop);
t=t/fs;
f=(f/pi)*(fs/2);
V=abs(v);
%%NMF parameters
r=40;
nIter=50;
%%Calculating Factorized forms using NMF
[W_noise,H,KL]=myNMF(V,r,nIter);

%%Plotting W
k=1;
figure(1)
 for i=1:7:40
 subplot(1,5,k)
 plot(f(1024:1536),W_noise(1024:1536,i))
 title('Dictionary Matrix');
 xlabel('Frequency(Hz)');
 k=k+1;
 end
 
% figure(2)
% for i=1:r
% subplot(1,r,i)
% plot(H(i,:))
% end

%%Reconstructed spectrogram
V_recon = W_noise*H;
[v_recon_a, v_recon_b] = pol2cart(angle(v),V_recon);
v_recon=v_recon_a + 1i*v_recon_b;

% %%Reconstructed speech spectrogram
% figure(3)
% surf(t,f(1024:2048),log(V(1024:2048,:)),'EdgeColor','none');
% axis xy; axis tight; colormap(jet);view(0,90);
% 
% %%Reconstructed speech spectrogram
% figure(4)
% surf(t,f(1024:2048),log(V_recon(1024:2048,:)),'EdgeColor','none');
% axis xy; axis tight; colormap(jet);view(0,90);

%%Reconstructing audio signal
x_recon=real(istft(v_recon,'FFTLength',2048,'Window',win,'OverlapLength',length(win)-hop,'Method','ola'));
audiowrite('noisetrain_recon.wav',x_recon,fs);