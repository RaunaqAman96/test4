function path = myViterbi(transMat, loglikeMat, initProb)
% Implementation of the Viterbi algorithm to find the path of states that has the
% highest posterior probability in a finite-state hidden Markov model
% (HMM).
%
% Input
%   - transMat      : the transition probability matrix, P(S_n | S_n-1).
%                       Rows correspond to the starting states; columns
%                       corresond to the ending states. Each row sums to 1.
%                       (size: nState * nState) A
%   - loglikeMat    : the log-likelihood matrix of each state to explain
%                       each observation, log( P(O_n | S_n) ) Rows
%                       correspond to states; columns correspond to
%                       observations. (size: nState * nObserv) log(B)
%   - initProb      : the initial probability of all states, P(S_0). A
%                       column vector with nState elements. pi
%
% Output
%   - path          : the best path of states (S_1, ..., S_N) that gives
%                       the maximal posterior probability, P(S_1, ..., S_N
%                       | O_1, ... O_N). A column vector with nObserv elements.
%
% Author: XXX
% Created: XXX
% Last modified: XXX

if nargin<3     % use a uniform distribution if the initial probability is not given
    initProb = ones(size(transMat,1),1)/size(transMat,1); 
end
if size(transMat,1) ~= size(loglikeMat, 1) || size(transMat,1) ~= length(initProb)
    error('The number of states is not consistent in the transition matrix, the likelihood matrix, and the initial probability!');
end

% Your implementation starts here...

for j=1:length(initProb)
    v(j,1)=log(initProb(j))+loglikeMat(j,1);            %%Initialization of Viterbi best score
end

arg_max_va=zeros(65,1);                                 %%Initialization of Viterbi best score location

%%Updation(in the log space to avoid underflow)
for t=2:size(loglikeMat, 2)
    for j=1:length(initProb)
        for i=1:length(initProb)
            va(i)=v(i,t-1)+log(transMat(i,j));
        end
        [max_va,arg_max_va(j,t)]=max(va);
        v(j,t)=max_va+loglikeMat(j,t);
    end
end

%%Termination
k=size(v,2);
[~,path]=max(v(:,k)); 
k=k-1;

%%Tracing back to find the best sequence
while k>0                       
    path = [arg_max_va(path(1),k+1),path];
    k=k-1;
end
end