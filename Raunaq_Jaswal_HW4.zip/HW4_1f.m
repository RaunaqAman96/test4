clearvars -except W_speech W_noise;
clc;

[x,fs]=audioread("noisyspeech.wav");

win=hamming(1024);
hop=512;
%%Calculating spectrogram
[v,f,t]=stft(x,'FFTLength',2048,'Window',win,'OverlapLength',length(win)-hop);
t=t/fs;
f=(f/pi)*(fs/2);
V=abs(v);
W = [W_speech W_noise]; %%Total dictionary elements
r = length(W(1,:));
%%NMF parameters
nIter=50;
[m,n]=size(V);
initH = rand(r, n);
%%Calculating Factorized forms using NMF
[W_noisyspeech,H,KL]=myNMF(V,r,nIter,W,initH,0,1);

%%Reconstructing speech spectrogram
V_speech_recon = W_speech*H(1:35,:);
[v_speech_recon_a, v_speech_recon_b] = pol2cart(angle(v),V_speech_recon);
v_speech_recon=v_speech_recon_a + 1i*v_speech_recon_b;

%%Reconstructing noise spectrogram
V_noise_recon = W_noise*H(36:75,:);
[v_noise_recon_a, v_noise_recon_b] = pol2cart(angle(v),V_noise_recon);
v_noise_recon=v_noise_recon_a + 1i*v_noise_recon_b;

 figure(3)
 surf(t,f(1024:2048),log(V_speech_recon(1024:2048,:)),'EdgeColor','none');
 axis xy; axis tight; colormap(jet);view(0,90);
 
 figure(4)
 surf(t,f(1024:2048),log(V_noise_recon(1024:2048,:)),'EdgeColor','none');
 axis xy; axis tight; colormap(jet);view(0,90);

%%Reconstructing separated speech signal
x_speech_recon=real(istft(v_speech_recon,'FFTLength',2048,'Window',win,'OverlapLength',length(win)-hop,'Method','ola'));
audiowrite('speech_sep.wav',x_speech_recon,fs);
%%Reconstructing separated noise signal
x_noise_recon=real(istft(v_noise_recon,'FFTLength',2048,'Window',win,'OverlapLength',length(win)-hop,'Method','ola'));
audiowrite('noise_sep.wav',x_noise_recon,fs);