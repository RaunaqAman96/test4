clear;
clc;

[x,fs]=audioread("piano.wav");      

win=hamming(2048);
hop=512;

%%Calculating spectrogram
[v,f,t]=stft(x,'FFTLength',2048,'Window',win,'OverlapLength',length(win)-hop);
t=t/fs;
f=(f/pi)*(fs/2);
V=abs(v);
%%NMF parameters
r=5;
nIter=50;
%%Calculating Factorized forms using NMF
[W,H,KL]=myNMF(V,r,nIter);

%%Plotting W
figure(1)
for i=1:r
subplot(1,r,i)
plot(f(1024:1152),W(1024:1152,i))
title('Dictionary Matrix');
xlabel('Frequency(Hz)');
end

%%Plotting H
figure(2)
for i=1:r
subplot(1,r,i)
plot(t,H(i,:))
title('Activation Matrix');
xlabel('Time(s)');
end

%%Reconstructed spectrogram
V_recon = W*H;
[v_recon_a, v_recon_b] = pol2cart(angle(v),V_recon);
v_recon=v_recon_a + 1i*v_recon_b;

%%plotting original spectrogram
figure(3)
surf(t,f(1024:2048),log(V(1024:2048,:)),'EdgeColor','none');
axis xy; axis tight; colormap(jet);view(0,90);
ylabel('Frequency (Hz)');
xlabel('Time (s)');
title('Original Spectrogram');

%%plotting reconstructed spectrogram
figure(4)
surf(t,f(1024:2048),log(V_recon(1024:2048,:)),'EdgeColor','none');
axis xy; axis tight; colormap(jet);view(0,90);
ylabel('Frequency (Hz)');
xlabel('Time (s)');
title('Reconstructed Spectrogram');

%%Reconstructing audio signal
x_recon=real(istft(v_recon,'FFTLength',2048,'Window',win,'OverlapLength',length(win)-hop,'Method','ola'));
audiowrite('piano_recon_r5.wav',x_recon,fs);