clear;
clc;

load('pitchdata.mat');                     %%Load the probabilites
[x,fs]=audioread('female_factory.wav');    %%Load the audio file
win=hamming(1024);
hop=160;
[x_stft,f ,t]=stft(x,'Window',win,'OverlapLength',length(win)-hop,'FFTLength',4*length(win)); %%Calculate the spectrogram
x_stft = abs(x_stft);       %%Calculate the magnitude spectrogram
t=t/fs;
f=(f/pi)*(fs/2);

%%Calculating the pitch hypotheses
midi_freq=(((2:length(initProb))-2)*0.5)+35.25;
freq=440*2.^((midi_freq-69)/12);
freq=[0,freq];

%%Finding the maximum log-likelihood and its corresponding frequency
for i=1:size(loglikeMat, 2)
    [~,pitch_loc]=max(loglikeMat(:,i));
    pitch_freq(i)=freq(pitch_loc);
end

%%Plot spectrogram and corresponding frequency
figure(1)
hold on
imagesc(t,f(2048:2172),log(x_stft(2048:2172,:)))
axis xy; axis tight; colormap(jet);view(0,90);
xlabel('time(s)');
ylabel('Frequency(Hz)');
stem(t,pitch_freq,'filled','LineStyle','none','Color','black','MarkerEdgeColor','black','MarkerSize',3);
hold off

%%Use Viterbi algorithm to find the best sequence
path=myViterbi(transMat,loglikeMat,initProb);
for i=1:length(path)
    path_freq(i)=freq(path(i));
end

%%Plot spectrogram and corresponding path
figure(2)
hold on
imagesc(t,f(2048:2172),log(x_stft(2048:2172,:)))
axis xy; axis tight; colormap(jet);view(0,90);
xlabel('time(s)');
ylabel('Frequency(Hz)');
stem(t,path_freq,'filled','LineStyle','none','Color','black','MarkerEdgeColor','black','MarkerSize',3);
hold off
