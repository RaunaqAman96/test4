clear;
clc;

[x1,fs1]=audioread('speech_sep.wav');
[x2,fs2]=audioread('speech_test.wav');
[x3,fs3]=audioread('noise_sep.wav');
[x4,fs4]=audioread('noise_test.wav');

[SDR,SIR,SAR,perm]=bss_eval_sources([x1 x3]',[x2(1:length(x1)) x4(1:length(x1))]');

